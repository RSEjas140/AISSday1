# -*- coding: utf-8 -*-
"""
Created on Fri Jul 12 13:51:52 2024

@author: jes15-admin
"""

#pip install opencv-python
import cv2

def show_image(img):
    
    cv2.imshow('image', img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

image = cv2.imread("data/crop_images/jute/jute018a.jpeg")

show_image(image)

edges = cv2.Canny(image, 100, 200)

show_image(edges)