# -*- coding: utf-8 -*-
"""
Created on Thu Jul 4 13:51:52 2024

Simple niave implimentation for greyscaling an image and finding edges

@author: jes15-admin
"""

#pip install opencv-python
import cv2

# my function for displaying images
def show_image(img):
    """ docstring
    Pass in an image and it will be displayed until you press any key

    Parameters
    ----------
    img : Array
        Image we want to display.

    Returns
    -------
    None.

    """    
    #show image
    cv2.imshow('image', img)
    #wait until a key is pressed
    cv2.waitKey(0)
    #close image
    cv2.destroyAllWindows()
    
#read image from file path
image = cv2.imread("data/crop_images/jute/jute018a.jpeg")

#use my function to display it
show_image(image)

#turn it grey
grey_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

#use my function to display it
show_image(grey_image)

#find the edges in the image
edges = cv2.Canny(grey_image, 100, 200)

#show the edges
show_image(edges)