# -*- coding: utf-8 -*-
"""
Created on Thu Jul 4 14:22:50 2024

Simple niave implimentation for opening and plotting tabular data

@author: jas140
"""

#pandas will need to be installed if it hasn't already
import pandas as pd

#matplotlib will need to be installed if it hasn't already
import matplotlib.pyplot as plt

#read data from csv
iris = pd.read_csv("data/iris.csv")

#show first 5 data points
print(iris.head())

#Create a colour map that can be used to convert key to value
colour_map = {'Setosa': 'red', 'Versicolor': 'green', 'Virginica': 'blue'}

#create a list of colours to use for scatter plot
colours = iris['variety'].map(colour_map)

#plot the relationship between sepal length and width
iris.plot.scatter('petal.length','petal.width', c = colours)