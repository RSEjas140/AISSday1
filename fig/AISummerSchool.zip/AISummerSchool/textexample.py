# -*- coding: utf-8 -*-
"""
Created on Thu Jul 4 14:21:50 2024

Simple niave implimentation for if and how often words appear in a text file (utf-8 encoding)

@author: jas140
"""


word_dict = {}
# open the story specified by filename using encoding UTF8
with open( "data/bed_time_stories/2. Who is the thief.txt", encoding='utf-8') as story:
    
    #for each line in the file
    for line in story:
            
        words = line.split()
        #print(words)
        #for each word in the line
        for word in words:
    
            #if we have seen the word before increment the occurances
            if word in word_dict:
                word_dict[word] += 1
            
            #if we havent, put the word in and set the count to 1
            else:
                word_dict[word] = 1
                        
        
# find the top 5 words (dictionaries are not sorted by value)
#sort items (key:value) in dictrionary, sort on item[1] (value) from largest to smallest
sorted_by_occurance = sorted(word_dict.items(), key = lambda item: item[1], reverse = True)
#print the top 10 words and their number of occurances
print("Top 10 words by occurance:")
print(sorted_by_occurance[:10])
    
    